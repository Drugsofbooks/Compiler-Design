#include <iostream>
#include <string>
#include <fstream>

using namespace std;

bool isKeyword(const std::string& word)
{
    const std::string keywords[] = {"int", "float", "double", "char", "if", "else", "while", "for", "return"};

    for (const std::string& keyword : keywords)
    {
        if (word == keyword)
        {
            return true;
        }
    }

    return false;
}


int main()
{
    string myText;
    ifstream MyReadFile("sourcefile.txt");
    while (getline (MyReadFile, myText))
    {
        cout << "Expression is : " << myText << endl;
    }

    std::string currentConstant;
    bool inConstant = false;

    std::cout << "\n"<< "Constants : ";

    for (char ch : myText)
    {
        if ((ch >= '0' && ch <= '9') || ch == '.')
        {
            inConstant = true;
            currentConstant += ch;
        }
        else
        {

            if (inConstant)
            {
                std::cout << currentConstant << " ";
                currentConstant = "";
                inConstant = false;
            }
        }
    }

    if (inConstant)
    {
        std::cout << currentConstant << " ";
    }

    std::cout << std::endl;


    std::string currentWord = "";
    for (char c : myText)
    {
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_')
        {
            currentWord += c;
        }
        else
        {
            if (!currentWord.empty() && isKeyword(currentWord))
            {
                std::cout << "Keywords  : " << currentWord << std::endl;
            }
            currentWord = "";
        }
    }

    if (!currentWord.empty() && isKeyword(currentWord))
    {
        std::cout << "Keywords  : " << currentWord << std::endl;
    }



    char currentChar;
    std::string operatorLabel;

    std::cout << "Operators : ";

    for (size_t i = 0; i < myText.length(); i++)
    {
        currentChar = myText[i];

        if (currentChar == '=')
        {
            if (i < myText.length() - 1 && myText[i + 1] == '=')
            {
                operatorLabel = "== Equal to";
                i++;
            }
            else
            {
                operatorLabel = "!= Not Equal to";
            }
        }

        else if (currentChar == '>')
        {
            if (i < myText.length() - 1 && myText[i + 1] == '=')
            {
                operatorLabel = ">= Greater than or equal to";
                i++;
            }
            else
            {
                operatorLabel = "> Greater than";
            }
        }

        else if (currentChar == '<')
        {
            if (i < myText.length() - 1 && myText[i + 1] == '=')
            {
                operatorLabel = "<= Less than or equal to";
                i++;
            }
            else
            {
                operatorLabel = "< Less than";
            }
        }

        else
        {
            continue;
        }

        std::cout << operatorLabel << std::endl;
    }

    std::cout << "Operators : ";

    for (char c : myText)
    {
        if (c=='+' || c=='-' || c=='*' || c=='/' || c=='%' ||c=='=')
        {
            std::cout << c << " ";
        }
    }

    std::cout << "\n";

    MyReadFile.close();

    return 0;
}


