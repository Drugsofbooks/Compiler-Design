#include <iostream>
#include <string>
using namespace std ;

int main ()
{
    string firstName="Abid";
    string lastName="Nazir";
    string fullName=firstName+" "+lastName;
    cout << "Full Name is : " << fullName ;

return 0;
}
